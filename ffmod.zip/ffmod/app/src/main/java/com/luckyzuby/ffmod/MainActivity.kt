package com.luckyzuby.ffmod

import android.content.Intent
import android.net.VpnService
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {

    private lateinit var btnStart: Button
    private lateinit var btnStop: Button
    private lateinit var tvStatus: TextView
    private lateinit var rvMods: RecyclerView
    private lateinit var adapter: ModAdapter
    private val modManager = ModManager()
    private var isRunning = false

    companion object {
        const val VPN_REQUEST_CODE = 100
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        btnStart = findViewById(R.id.btn_start)
        btnStop = findViewById(R.id.btn_stop)
        tvStatus = findViewById(R.id.tv_status)
        rvMods = findViewById(R.id.rv_mods)

        adapter = ModAdapter(modManager.getMods()) { mod ->
            modManager.toggleMod(mod.id)
            // Tampilkan toast untuk fitur baru
            when (mod.id) {
                "aim_head" -> Toast.makeText(this, "Aim Head: Bidik otomatis ke kepala aktif!", Toast.LENGTH_SHORT).show()
                "drag_head" -> Toast.makeText(this, "Drag Head: Drag crosshair ke kepala aktif!", Toast.LENGTH_SHORT).show()
                "unlock_120fps" -> Toast.makeText(this, "Unlock 120 FPS: Frame rate dibuka!", Toast.LENGTH_SHORT).show()
            }
        }
        rvMods.layoutManager = LinearLayoutManager(this)
        rvMods.adapter = adapter

        btnStart.setOnClickListener { startProxy() }
        btnStop.setOnClickListener { stopProxy() }
        
        updateUI(false)
    }

    private fun startProxy() {
        val intent = VpnService.prepare(this)
        if (intent != null) {
            startActivityForResult(intent, VPN_REQUEST_CODE)
        } else {
            startVpnService()
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == VPN_REQUEST_CODE && resultCode == RESULT_OK) {
            startVpnService()
        } else {
            Toast.makeText(this, "VPN permission denied", Toast.LENGTH_SHORT).show()
        }
    }

    private fun startVpnService() {
        val intent = Intent(this, ProxyService::class.java)
        intent.putStringArrayListExtra("mods", modManager.getActiveMods())
        startService(intent)
        isRunning = true
        updateUI(true)
        
        val activeCount = modManager.getActiveMods().size
        Toast.makeText(this, "Proxy started! $activeCount mods active", Toast.LENGTH_SHORT).show()
    }

    private fun stopProxy() {
        stopService(Intent(this, ProxyService::class.java))
        isRunning = false
        updateUI(false)
        Toast.makeText(this, "Proxy stopped", Toast.LENGTH_SHORT).show()
    }

    private fun updateUI(isRunning: Boolean) {
        btnStart.isEnabled = !isRunning
        btnStop.isEnabled = isRunning
        tvStatus.text = if (isRunning) "ACTIVE" else "IDLE"
        tvStatus.setTextColor(if (isRunning) 0xFF00E676.toInt() else 0xFFFF1744.toInt())
        rvMods.isEnabled = !isRunning
    }
}