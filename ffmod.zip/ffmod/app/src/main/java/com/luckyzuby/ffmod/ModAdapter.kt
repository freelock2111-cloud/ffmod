package com.luckyzuby.ffmod

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.switchmaterial.SwitchMaterial

class ModAdapter(
    private val mods: List<Mod>,
    private val onToggle: (Mod) -> Unit
) : RecyclerView.Adapter<ModAdapter.ModViewHolder>() {

    // Daftar fitur baru
    private val newMods = setOf("aim_head", "drag_head", "unlock_120fps")

    class ModViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val tvName: TextView = itemView.findViewById(R.id.tv_mod_name)
        val tvDesc: TextView = itemView.findViewById(R.id.tv_mod_desc)
        val tvBadge: TextView = itemView.findViewById(R.id.tv_badge)
        val switch: SwitchMaterial = itemView.findViewById(R.id.switch_mod)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ModViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_mod, parent, false)
        return ModViewHolder(view)
    }

    override fun onBindViewHolder(holder: ModViewHolder, position: Int) {
        val mod = mods[position]
        holder.tvName.text = mod.name
        holder.tvDesc.text = mod.description
        holder.switch.isChecked = mod.isActive
        
        // Tampilkan badge NEW untuk fitur baru
        if (newMods.contains(mod.id)) {
            holder.tvBadge.visibility = View.VISIBLE
        } else {
            holder.tvBadge.visibility = View.GONE
        }
        
        holder.switch.setOnCheckedChangeListener { _, isChecked ->
            mod.isActive = isChecked
            onToggle(mod)
        }
    }

    override fun getItemCount(): Int = mods.size
}