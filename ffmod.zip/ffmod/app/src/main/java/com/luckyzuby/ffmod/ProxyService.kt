package com.luckyzuby.ffmod

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import androidx.core.app.NotificationCompat
import java.io.FileInputStream
import java.io.FileOutputStream

class ProxyService : VpnService() {

    private var vpnInterface: ParcelFileDescriptor? = null
    private var running = false
    private var activeMods: List<String> = emptyList()

    companion object {
        const val CHANNEL_ID = "ff_proxy_channel"
        const val NOTIFICATION_ID = 1
    }

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        intent?.let {
            activeMods = it.getStringArrayListExtra("mods") ?: emptyList()
        }
        startProxy()
        startForeground(NOTIFICATION_ID, createNotification())
        return START_STICKY
    }

    private fun startProxy() {
        // 1. Build VPN interface
        val builder = Builder()
        builder.setAddress("10.0.0.1", 32)      // IP untuk VPN
        builder.addRoute("0.0.0.0", 0)          // Semua traffic
        builder.addAllowedApplication("com.dts.freefireth") // Hanya FF

        vpnInterface = builder.establish()
        running = true

        // 2. Jalankan loop proxy di background
        Thread {
            proxyLoop()
        }.start()
    }

    private fun proxyLoop() {
        val input = FileInputStream(vpnInterface?.fileDescriptor)
        val output = FileOutputStream(vpnInterface?.fileDescriptor)
        val buffer = ByteArray(1500) // MTU standar

        while (running) {
            try {
                val length = input.read(buffer)
                if (length > 0) {
                    // Ambil packet, modifikasi, kirim balik
                    val packet = buffer.copyOf(length)
                    val modified = PacketModifier.modify(packet, activeMods)
                    output.write(modified)
                    output.flush()
                }
            } catch (e: Exception) {
                break
            }
        }
    }

    override fun onDestroy() {
        running = false
        vpnInterface?.close()
        super.onDestroy()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "FF Proxy Service",
                NotificationManager.IMPORTANCE_LOW
            )
            getSystemService(NotificationManager::class.java)
                .createNotificationChannel(channel)
        }
    }

    private fun createNotification(): Notification {
        val intent = Intent(this, MainActivity::class.java)
        val pendingIntent = PendingIntent.getActivity(
            this, 0, intent,
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M)
                PendingIntent.FLAG_IMMUTABLE
            else
                0
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Lucky Zuby AI Breaker")
            .setContentText("Proxy active with ${activeMods.size} mods")
            .setSmallIcon(android.R.drawable.ic_menu_share)
            .setContentIntent(pendingIntent)
            .build()
    }
}