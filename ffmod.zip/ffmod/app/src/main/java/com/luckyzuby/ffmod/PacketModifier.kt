package com.luckyzuby.ffmod

import java.nio.ByteBuffer
import java.nio.ByteOrder

object PacketModifier {
    
    fun modify(payload: ByteArray, activeMods: List<String>): ByteArray {
        var modified = payload
        
        activeMods.forEach { modId ->
            when (modId) {
                // Fitur lama
                "super_jump" -> modified = modifyJump(modified)
                "back_jump" -> modified = modifyBackJump(modified)
                "quick_switch" -> modified = modifyQuickSwitch(modified)
                "aim_assist" -> modified = modifyAimAssist(modified)
                "sensi_unlock" -> modified = modifySensitivity(modified)
                "neck_hs" -> modified = modifyHitbox(modified)
                
                // ===== FITUR BARU =====
                "aim_head" -> modified = modifyAimHead(modified)
                "drag_head" -> modified = modifyDragHead(modified)
                "unlock_120fps" -> modified = modifyFPS(modified)
            }
        }
        return modified
    }

    // ===== FITUR LAMA (tetap sama) =====
    
    private fun modifyJump(data: ByteArray): ByteArray {
        try {
            for (i in 0 until data.size - 4) {
                if (data[i] == 0x00 && data[i+1] == 0x00 && data[i+2] == 0x00 && data[i+3] == 0x40) {
                    data[i] = 0x00; data[i+1] = 0x00; data[i+2] = 0x60; data[i+3] = 0x40
                    return data
                }
            }
        } catch (_: Exception) {}
        return data
    }

    private fun modifyAimAssist(data: ByteArray): ByteArray {
        try {
            for (i in 0 until data.size - 4) {
                if (data[i] == 0x00 && data[i+1] == 0x00 && data[i+2] == 0x80 && data[i+3] == 0x3F) {
                    data[i] = 0x66; data[i+1] = 0x66; data[i+2] = 0xE6; data[i+3] = 0x3F
                    return data
                }
            }
        } catch (_: Exception) {}
        return data
    }

    private fun modifySensitivity(data: ByteArray): ByteArray {
        try {
            for (i in 0 until data.size - 4) {
                if (data[i] == 0x00 && data[i+1] == 0x00 && data[i+2] == 0x00 && data[i+3] == 0x40) {
                    data[i] = 0x00; data[i+1] = 0x00; data[i+2] = 0xA0; data[i+3] = 0x40
                    return data
                }
            }
        } catch (_: Exception) {}
        return data
    }

    private fun modifyHitbox(data: ByteArray): ByteArray {
        try {
            for (i in 0 until data.size - 4) {
                if (data[i] == 0x00 && data[i+1] == 0x00 && data[i+2] == 0x80 && data[i+3] == 0x3F) {
                    data[i] = 0x00; data[i+1] = 0x00; data[i+2] = 0xC0; data[i+3] = 0x3F
                    return data
                }
            }
        } catch (_: Exception) {}
        return data
    }

    private fun modifyBackJump(data: ByteArray): ByteArray {
        try {
            for (i in 0 until data.size - 1) {
                if (data[i] == 0x00 && data[i+1] == 0x01) {
                    data[i] = 0x01; data[i+1] = 0x00
                    return data
                }
            }
        } catch (_: Exception) {}
        return data
    }

    private fun modifyQuickSwitch(data: ByteArray): ByteArray {
        try {
            for (i in 0 until data.size - 4) {
                if (data[i] == 0x00 && data[i+1] == 0x00 && data[i+2] == 0x80 && data[i+3] == 0x3F) {
                    data[i] = 0x9A; data[i+1] = 0x99; data[i+2] = 0x99; data[i+3] = 0x3E
                    return data
                }
            }
        } catch (_: Exception) {}
        return data
    }

    // ========================================
    // ===== FITUR BARU: AIM HEAD =====
    // ========================================
    private fun modifyAimHead(data: ByteArray): ByteArray {
        try {
            // Pattern: aim assist target bias (default ke body)
            // Modifikasi agar target bias ke head
            for (i in 0 until data.size - 4) {
                // Cari pattern float 0.5 (bias body)
                if (data[i] == 0x00 && data[i+1] == 0x00 && data[i+2] == 0x00 && data[i+3] == 0x3F) {
                    // Ganti dengan 0.0 (bias head)
                    data[i] = 0x00; data[i+1] = 0x00; data[i+2] = 0x00; data[i+3] = 0x00
                    return data
                }
                // Pattern alternatif: 0.3
                if (data[i] == 0x9A && data[i+1] == 0x99 && data[i+2] == 0x99 && data[i+3] == 0x3E) {
                    data[i] = 0x00; data[i+1] = 0x00; data[i+2] = 0x00; data[i+3] = 0x00
                    return data
                }
            }
        } catch (_: Exception) {}
        return data
    }

    // ========================================
    // ===== FITUR BARU: DRAG HEAD =====
    // ========================================
    private fun modifyDragHead(data: ByteArray): ByteArray {
        try {
            // Pattern: parameter smoothing drag
            // Dinaikkan agar drag ke head lebih agresif
            for (i in 0 until data.size - 4) {
                // Cari pattern float 1.0 (drag sensitivity normal)
                if (data[i] == 0x00 && data[i+1] == 0x00 && data[i+2] == 0x80 && data[i+3] == 0x3F) {
                    // Ganti dengan 3.0 (drag lebih agresif)
                    data[i] = 0x00; data[i+1] = 0x00; data[i+2] = 0x40; data[i+3] = 0x40
                    return data
                }
                // Pattern alternatif: 0.5
                if (data[i] == 0x00 && data[i+1] == 0x00 && data[i+2] == 0x00 && data[i+3] == 0x3F) {
                    data[i] = 0x00; data[i+1] = 0x00; data[i+2] = 0x40; data[i+3] = 0x40
                    return data
                }
            }
        } catch (_: Exception) {}
        return data
    }

    // ========================================
    // ===== FITUR BARU: UNLOCK 120 FPS =====
    // ========================================
    private fun modifyFPS(data: ByteArray): ByteArray {
        try {
            // Pattern: max frame rate (60 FPS = 3.75f dalam delta time)
            // 60 FPS = 0x00 0x00 0x70 0x42 (60.0f)
            // 120 FPS = 0x00 0x00 0xF0 0x42 (120.0f)
            for (i in 0 until data.size - 4) {
                // Cari pattern 60.0f
                if (data[i] == 0x00 && data[i+1] == 0x00 && data[i+2] == 0x70 && data[i+3] == 0x42) {
                    // Ganti dengan 120.0f
                    data[i] = 0x00; data[i+1] = 0x00; data[i+2] = 0xF0; data[i+3] = 0x42
                    return data
                }
                // Pattern 60.0f alternatif (little endian)
                if (data[i] == 0x00 && data[i+1] == 0x00 && data[i+2] == 0x70 && data[i+3] == 0x42) {
                    data[i] = 0x00; data[i+1] = 0x00; data[i+2] = 0xF0; data[i+3] = 0x42
                    return data
                }
            }
        } catch (_: Exception) {}
        return data
    }
}