package com.luckyzuby.ffmod

data class Mod(
    val id: String,
    val name: String,
    val description: String,
    var isActive: Boolean = false
)

class ModManager {
    
    private val mods = listOf(
        // Fitur lama
        Mod("back_jump", "Back Jump Clássico", "Ativa o pulo para trás como nas versões antigas do jogo."),
        Mod("quick_switch", "Troca de Arma Rápida", "Permite alternar entre armas quase instantaneamente."),
        Mod("super_jump", "Super Pulo", "Aumenta a altura do pulo do personagem."),
        Mod("aim_assist", "Aim Assist", "Receba uma ajuda na mira padrão do Jogo."),
        Mod("sensi_unlock", "Sensi Unlock", "Permite Ajustar a Sensibilidade Acima do Permitido pelo Jogo."),
        Mod("neck_hs", "HS Pescoço", "Acerte Headshots abaixo da cabeça do inimigo."),
        
        // ===== FITUR BARU =====
        Mod("aim_head", "Aim Head", "[NEW] Bidik otomatis ke kepala musuh."),
        Mod("drag_head", "Drag Head", "[NEW] Tarik crosshair ke kepala saat menembak."),
        Mod("unlock_120fps", "Unlock 120 FPS", "[NEW] Buka batas frame rate hingga 120 FPS.")
    )
    
    fun getMods(): List<Mod> = mods
    fun getActiveMods(): ArrayList<String> = mods.filter { it.isActive }.map { it.id } as ArrayList<String>
    
    fun toggleMod(id: String) {
        mods.find { it.id == id }?.let { it.isActive = !it.isActive }
    }
}